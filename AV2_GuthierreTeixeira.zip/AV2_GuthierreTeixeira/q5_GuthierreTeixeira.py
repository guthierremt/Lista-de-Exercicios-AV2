from flask import Flask, request, render_template

app = Flask(__name__, template_folder='html')

users = lambda : {
    "cleitin" : "136578"
,   "flavin" : "123456"
,   "flavin" : "123456"
}

welcome = lambda : f'WELCOME {request.form["login"]}!!'
wrong = lambda : 'WRONG PASSWORD!!!!'
invalid = lambda : 'User does not exist!'
password_matches = lambda dic : dic [f'{request.form["login"]}'] == f'{request.form["password"]}'
check_password = lambda : welcome () if password_matches (users ()) else wrong ()
check_if_user_exists = lambda : check_password () if f'{request.form["login"]}' in users () else invalid ()
reqresp = lambda : check_if_user_exists () if request.method == 'POST' else render_template('index.html')
app.add_url_rule('/index/', 'index', reqresp, methods=['GET', 'POST'])
app.run(host='0.0.0.0', port=8080)