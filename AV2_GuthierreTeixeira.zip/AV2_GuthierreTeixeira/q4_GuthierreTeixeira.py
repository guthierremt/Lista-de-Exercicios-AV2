import mysql.connector


dbsql = mysql.connector.connect(user='root', password="Admin!#%&007", host="localhost")

crs = dbsql.cursor()

printTable = lambda res : [print (x) for x in res]
execsqlcmd = lambda cmd, crs: crs.execute (cmd)

createTable = lambda table, attrs, crs : execsqlcmd ("CREATE TABLE " + table + " (" + attrs + ");\n", crs)
createDataBase = lambda dbname, crs : execsqlcmd ("CREATE DATABASE  " + dbname + ";\n", crs)
dropDataBase = lambda dbname, crs : execsqlcmd ("DROP DATABASE " + dbname + ";\n", crs)
dropTable = lambda dbname, crs : execsqlcmd ("DROP TABLE " + dbname + ";\n", crs)
useDataBase = lambda dbname, crs : execsqlcmd ("USE " + dbname + ";\n", crs)
selectFromWhere = lambda attrs, table, wherecond, crs : execsqlcmd ("SELECT " + attrs + " FROM " + table + " WHERE " + wherecond + ";", crs)
insertIn = lambda table, attrs, values, crs : execsqlcmd ("INSERT INTO " + table + " (" + attrs + ")" + " VALUES (" + values + ");", crs)
updateTable = lambda table, setValues, where_cond, crs: execsqlcmd("UPDATE " + table + " SET " + setValues + " WHERE " + where_cond + ";", crs)
deleteFromTable = lambda table, where_cond, crs: execsqlcmd("DELETE FROM " + table + " WHERE " + where_cond + ";", crs)


dropDataBase("mydb", crs)
createDataBase("mydb", crs)
useDataBase ("mydb", crs)


createTable("usuarios", "id INT, name VARCHAR (255) , console VARCHAR (30)", crs)
insertIn("usuarios", "id , name, console", "'1', 'José', 'PS3'", crs)
insertIn("usuarios", "id , name, console", "'2', 'Pedro', 'PS1'", crs)
insertIn("usuarios", "id , name, console", "'3', 'Carlos', 'PS2'", crs)
insertIn("usuarios", "id , name, console", "'4', 'Thiago', 'PS4'", crs)

createTable ("jogos", "id INT, name VARCHAR (255), data_lancamento DATE", crs)
insertIn ("jogos", "id , name, data_lancamento", "'1', 'GTA 5', '2019-08-09'", crs)
insertIn ("jogos", "id , name, data_lancamento", "'2', 'GTA 4', '2012-08-09'", crs)
insertIn ("jogos", "id , name, data_lancamento", "'3', 'GTA San Andreas', '2017-08-09'", crs)
insertIn ("jogos", "id , name, data_lancamento", "'4', 'GTA Vice City', '2018-08-09'", crs)

# updateTable("usuarios", "console = 'XBOX'", "console = 'PS3'", crs)
# updateTable("jogos", "data_lancamento = '2010-05-05'", "id = 2", crs)
# deleteFromTable("usuarios", "name = 'Pedro'", crs)
# deleteFromTable("jogos", "id = 1", crs)


selectFromWhere ("*", "usuarios", "TRUE", crs)
res = crs.fetchall ()
print("Tabela Usuarios: ")
printTable (res)

selectFromWhere ("*", "jogos", "TRUE", crs)
res = crs.fetchall ()
print("\nTabela Jogos: ")
printTable (res)


dropTable("usuarios", crs)









