conta = {
    "00000000000": 100.00,
    "11111111111": 100.00,
    "22222222222": 200.00,
    "33333333333": 200.00,
    "44444444444": 200.00,
    "55555555555": 200.00,
    "66666666666": 200.00,
    "77777777777": 200.00,
    "88888888888": 200.00
}

# Função pra verificar se usuario possui uma conta ou não
checkAccount = lambda conta, cpf: print("Logado com sucesso") if cpf in conta else print("Conta não encontrada")

# Função pra fazer o saque se o mesmo tiver uma conta
drawMoney = lambda conta, cpf, money: conta.update({cpf: conta.get(cpf, 0) - money})  if cpf in conta and conta.get(cpf,0) >= money else print("Saque não permitido")

# Funçõa pra depositar caso possua uma conta
depositMoney = lambda conta, cpf, money: conta.update({cpf: conta.get(cpf, 0) + money}) if cpf in conta else print("CPF invalido")

checkAccount(conta, "9843216854")
checkAccount(conta, "00000000000")
drawMoney(conta, "00000000000", 30)
depositMoney(conta, "00000", 40)
print(conta)
