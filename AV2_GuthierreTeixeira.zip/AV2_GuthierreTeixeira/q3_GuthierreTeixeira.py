from PIL import Image, ImageEnhance

path = input("Coloque o caminho da imagem:")

imagem = Image.open(path)

# Estou utilizando a biblioteca ImageEnhance pra ajustar o brilho
ajustarBrilho = lambda imagem, fator: ImageEnhance.Brightness(imagem).enhance(fator)

# Imagem e o fator que deseja adicioanr para aumentar o brilho da imagem
imagemBrilho = ajustarBrilho(imagem, 4)

imagemBrilho.show()


