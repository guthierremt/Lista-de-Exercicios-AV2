from PIL import Image, ImageEnhance

path = input("Coloque o caminho da imagem:")

imagem = Image.open(path)

ajustarBrilho = lambda imagem, fator: ImageEnhance.Brightness(imagem).enhance(fator)

imagemBrilho = ajustarBrilho(imagem, 2)

imagemBrilho.show()


