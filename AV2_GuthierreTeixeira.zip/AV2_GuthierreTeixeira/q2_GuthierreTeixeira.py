from fileinput import filename
import os.path
import sys

# Função de cadastro
funCadastro = lambda login, senha: usuarios.update({login: senha}) if login not in usuarios else print("Login já existe")

# Função de login
funLogin = lambda login, senha: print("SUCESSO") if login in usuarios and usuarios[login] == senha else print("FRACASSO")

# Caminho do arquivo
path = "C:/Users/guthi/eclipse-workspace/AV2_GuthierreTeixeira/entrada.txt"

f2 = open(path, "w")

usuarios = {}

# Função pra armazenar o login e a senha no txt
writeFile = lambda f, usuarios: [f.write(f"{login}:{senha}\n") for login,senha in usuarios.items()]

funCadastro("jose", "123")
funCadastro("pedro", "1234")
funCadastro("cleito", "12345")
funCadastro("motomoto", "123456")
funLogin("jose", "123")
funLogin("xamuel", "1234")





print(usuarios)
writeFile (f2, usuarios)
f2.close()